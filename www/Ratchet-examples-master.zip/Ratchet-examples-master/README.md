### WIP

Various components implementing the `Ratchet\ComponentInterface` for application construction are located in `/src`. 

Server scripts are located in `/bin` and are run via `php bin/logged-terminal-chat.php`. 