$(document).on("pagecreate", "#exit", function () {
    navigator.app.exitApp();
});

