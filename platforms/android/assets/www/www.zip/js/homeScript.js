$(document).on("pagecreate", "#homePage", function () {

});
